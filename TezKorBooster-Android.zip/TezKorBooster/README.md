# TezKor Booster — Android (Shizuku bilan)

## Qanday yig'ish (APK olish)
1. [Android Studio](https://developer.android.com/studio) ni o'rnating.
2. **File → Open** orqali shu `TezKorBooster` papkasini oching.
3. Gradle avtomatik sinxronlanishini kuting (internet kerak, kutubxonalarni yuklab oladi).
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)** ni bosing.
5. Tayyor APK: `app/build/outputs/apk/debug/app-debug.apk`.
6. Shu faylni telefoningizga o'tkazib o'rnating (noma'lum manbalardan o'rnatishga ruxsat bering).

## Shizuku nima va qanday ulanadi
Shizuku — ADB (yoki root) huquqlarini oddiy ilovalarga xavfsiz tarzda "ijaraga beradigan" ochiq manbali vosita. Telefonda tizim darajasidagi amallar (boshqa dasturni to'xtatish, keshni tozalash) faqat shu orqali mumkin.

1. Play Market'dan yoki [shizuku.rikka.app](https://shizuku.rikka.app) dan **Shizuku** ilovasini o'rnating.
2. Shizuku ilovasidagi ko'rsatmaga ko'ra ishga tushiring:
   - **Kompyuter orqali (ADB)**: bir marta kompyuterga ulab, ko'rsatilgan buyruqni ishga tushirish kifoya.
   - **Root bo'lsa**: bitta tugma bosish bilan ishga tushadi.
3. TezKor Booster'ni oching → **"SHIZUKUGA ULANISH"** tugmasini bosing → ruxsat bering.
4. Shundan keyin **TEZLASHTIRISH** tugmasi haqiqiy tizim amallarini bajaradi: fondagi dasturlarni to'xtatadi va tizim keshini qisqartiradi.

Shizuku ishga tushmagan bo'lsa ham ilova ochiladi, lekin faqat RAM holatini ko'rsatadi — to'xtatish/tozalash amallari Shizuku ulanganidan keyin faollashadi.

## Loyiha tuzilishi
- `UserService.kt` — Shizuku orqali shell huquqi bilan ishga tushadigan qism (haqiqiy optimizatsiya shu yerda bajariladi)
- `ShizukuHelper.kt` — Shizuku bilan ulanish/ruxsat mantig'i
- `MainActivity.kt` — asosiy ekran (Jetpack Compose)
