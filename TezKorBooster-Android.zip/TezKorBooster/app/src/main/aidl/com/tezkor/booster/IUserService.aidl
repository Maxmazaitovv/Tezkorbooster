package com.tezkor.booster;

// Shizuku shu interfeysni "shell" (ADB) huquqi bilan ishlaydigan
// alohida jarayonda ishga tushiradi. Ilovaning o'zi bu huquqlarga ega emas —
// faqat shu orqali tizim darajasidagi amallarni bajara oladi.
interface IUserService {

    // Fonda ishlayotgan dasturni to'xtatadi (am force-stop)
    String forceStopPackage(String packageName);

    // Tizim darajasidagi vaqtinchalik fayllarni qisqartiradi (pm trim-caches)
    String trimSystemCaches();

    // Oddiy shell buyrug'ini bajarib, natijasini qaytaradi (diagnostika uchun)
    String runShell(String command);

    void destroy();
}
