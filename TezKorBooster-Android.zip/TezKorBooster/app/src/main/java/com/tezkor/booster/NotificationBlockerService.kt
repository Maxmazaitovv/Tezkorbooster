package com.tezkor.booster

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Foydalanuvchi tanlagan dasturlarning bildirishnomalarini avtomatik bekor qiladi. */
class NotificationBlockerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val pkg = sbn?.packageName ?: return
        if (pkg in Prefs.getBlockedNotifApps(this)) {
            cancelNotification(sbn.key)
        }
    }
}
