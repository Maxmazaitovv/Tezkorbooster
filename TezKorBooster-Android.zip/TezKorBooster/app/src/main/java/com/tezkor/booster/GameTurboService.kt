package com.tezkor.booster

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.*

/**
 * Fonda ishlab, tanlangan o'yin oldinga chiqqanda ekranga kichik suzuvchi
 * panel (RAM, tarmoq tezligi, ekran yangilanish tezligi, tez tozalash) chiqaradi.
 */
class GameTurboService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var monitorJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var lastRxBytes = 0L
    private var lastTime = 0L

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForeground(1, buildNotification())
        monitorJob = scope.launch { monitorLoop() }
    }

    private fun buildNotification(): Notification {
        val channelId = "game_turbo_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "O'yin Turbo", NotificationManager.IMPORTANCE_MIN)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        return androidx.core.app.NotificationCompat.Builder(this, channelId)
            .setContentTitle("O'yin Turbo faol")
            .setContentText("Tanlangan o'yinlar ochilganda panel chiqadi")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
    }

    private suspend fun monitorLoop() {
        val games = Prefs.getGameApps(this)
        while (true) {
            val fg = ForegroundAppUtil.current(this)
            withContext(Dispatchers.Main) {
                if (fg != null && fg in games) showOverlay() else hideOverlay()
            }
            delay(1500)
        }
    }

    private fun showOverlay() {
        if (overlayView != null) { updateStats(); return }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#DD101925"))
            setPadding(24, 18, 24, 18)
        }
        val ram = TextView(this).apply { setTextColor(Color.parseColor("#2FE8FF")); textSize = 11f; tag = "ram" }
        val net = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; tag = "net" }
        val refresh = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; tag = "refresh" }
        val cleanBtn = Button(this).apply {
            text = "TOZALASH"
            textSize = 10f
            setOnClickListener {
                scope.launch {
                    val svc = ShizukuHelper.service
                    AppListUtil.installedApps(packageManager).forEach { svc?.forceStopPackage(it.pkg) }
                }
            }
        }
        panel.addView(ram); panel.addView(net); panel.addView(refresh); panel.addView(cleanBtn)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 20
        params.y = 120

        // Panelni sudrab joyini o'zgartirish
        var initialX = 0; var initialY = 0; var touchX = 0f; var touchY = 0f
        panel.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).toInt()
                    params.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(panel, params)
                    true
                }
                else -> false
            }
        }

        try {
            windowManager.addView(panel, params)
            overlayView = panel
            updateStats()
        } catch (e: Exception) {
            // Overlay ruxsati yo'q — jim o'tkazib yuboramiz
        }
    }

    private fun updateStats() {
        val view = overlayView as? LinearLayout ?: return
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)

        val now = System.currentTimeMillis()
        val rx = TrafficStats.getTotalRxBytes()
        val speedKb = if (lastTime != 0L && rx > lastRxBytes) {
            ((rx - lastRxBytes) / 1024.0) / ((now - lastTime) / 1000.0)
        } else 0.0
        lastRxBytes = rx; lastTime = now

        val refreshRate = try {
            val dm = getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
            dm.getDisplay(android.view.Display.DEFAULT_DISPLAY)?.refreshRate ?: 60f
        } catch (e: Exception) { 60f }

        (view.findViewWithTag<TextView>("ram")).text = "RAM: ${mem.availMem / (1024 * 1024)} MB bo'sh"
        (view.findViewWithTag<TextView>("net")).text = "Tarmoq: ${"%.0f".format(speedKb)} KB/s"
        (view.findViewWithTag<TextView>("refresh")).text = "Ekran: ${refreshRate.toInt()} Hz"

        Handler(Looper.getMainLooper()).postDelayed({ if (overlayView != null) updateStats() }, 2000)
    }

    private fun hideOverlay() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {}
        }
        overlayView = null
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        hideOverlay()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
