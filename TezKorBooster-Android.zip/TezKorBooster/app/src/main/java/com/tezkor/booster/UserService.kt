package com.tezkor.booster

import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Shizuku shu klassni ADB/shell huquqi bilan alohida jarayonda ishga tushiradi.
 * Shuning uchun bu yerdagi Runtime.exec() chaqiruvlari oddiy ilova huquqidan
 * yuqori — fonda ishlayotgan boshqa dasturlarni to'xtatish, tizim keshini
 * qisqartirish kabi amallarni bajara oladi.
 */
class UserService : IUserService.Stub() {

    private fun exec(command: Array<String>): String {
        return try {
            val process = ProcessBuilder(*command).redirectErrorStream(true).start()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText()
            process.waitFor()
            output.trim()
        } catch (e: Exception) {
            "XATO: ${e.message}"
        }
    }

    override fun forceStopPackage(packageName: String): String {
        return exec(arrayOf("am", "force-stop", packageName))
            .ifEmpty { "OK: $packageName to'xtatildi" }
    }

    override fun trimSystemCaches(): String {
        return exec(arrayOf("pm", "trim-caches", "9999999999"))
            .ifEmpty { "OK: kesh qisqartirildi" }
    }

    override fun runShell(command: String): String {
        return exec(arrayOf("sh", "-c", command))
    }

    override fun destroy() {
        android.os.Process.killProcess(android.os.Process.myPid())
    }
}
