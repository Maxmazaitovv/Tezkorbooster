package com.tezkor.booster

import android.app.usage.UsageStatsManager
import android.content.Context

object ForegroundAppUtil {
    /** Hozir ekranda turgan dastur paketini topadi ("Foydalanish ma'lumotlariga kirish" ruxsati kerak). */
    fun current(ctx: Context): String? {
        return try {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis()
            val begin = end - 10_000
            val events = usm.queryEvents(begin, end)
            var lastPkg: String? = null
            val event = android.app.usage.UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    lastPkg = event.packageName
                }
            }
            lastPkg
        } catch (e: Exception) {
            null
        }
    }
}
