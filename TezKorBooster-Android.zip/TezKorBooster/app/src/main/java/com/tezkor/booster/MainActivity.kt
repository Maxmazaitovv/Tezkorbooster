package com.tezkor.booster

import android.app.ActivityManager
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

// Brend ranglari (veb-versiya bilan bir xil)
val BG = Color(0xFF070B12)
val SURFACE = Color(0xFF101925)
val CYAN = Color(0xFF2FE8FF)
val VIOLET = Color(0xFF8B5CF6)
val GREEN = Color(0xFF39FFA0)
val AMBER = Color(0xFFFFB84D)
val MUTED = Color(0xFF7489A3)

data class AppInfo(val label: String, val pkg: String, val icon: android.graphics.drawable.Drawable?)

class MainActivity : ComponentActivity() {

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        ShizukuHelper.isGranted.value = grantResult == PackageManager.PERMISSION_GRANTED
        if (ShizukuHelper.isGranted.value) ShizukuHelper.bindService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        ShizukuHelper.checkAvailability()

        setContent {
            BoosterApp(packageManager = packageManager)
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }
}

@Composable
fun BoosterApp(packageManager: PackageManager) {
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    val am = remember { context.getSystemService(ActivityManager::class.java) }

    var score by remember { mutableIntStateOf(62) }
    var boosting by remember { mutableStateOf(false) }
    var statusLog by remember { mutableStateOf("Shizuku bilan ulanish tekshirilmoqda...") }
    val memInfo = remember { ActivityManager.MemoryInfo() }
    var freeRam by remember { mutableStateOf(0L) }
    var totalRam by remember { mutableStateOf(1L) }

    fun refreshRam() {
        am?.getMemoryInfo(memInfo)
        freeRam = memInfo.availMem
        totalRam = memInfo.totalMem
    }

    val apps = remember {
        packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter {
                (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
                it.packageName != "com.tezkor.booster" &&
                packageManager.getLaunchIntentForPackage(it.packageName) != null
            }
            .map { AppInfo(packageManager.getApplicationLabel(it).toString(), it.packageName, null) }
    }
    var runningApps by remember { mutableStateOf(apps) }

    LaunchedEffect(Unit) {
        refreshRam()
        delay(400)
        statusLog = if (ShizukuHelper.isAvailable.value) {
            if (ShizukuHelper.isGranted.value) "Shizuku ulandi — to'liq optimizatsiya faol"
            else "Shizuku topildi, ruxsat kerak"
        } else "Shizuku ishlamayapti. Shizuku ilovasini o'rnating va ishga tushiring."
    }

    MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = SURFACE)) {
        Surface(color = BG, modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 28.dp)
            ) {
                // Header
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text("⚡ TezKor Booster", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (ShizukuHelper.isGranted.value) "● Shizuku faol" else "○ Shizuku kerak",
                        color = if (ShizukuHelper.isGranted.value) GREEN else AMBER,
                        fontSize = 12.sp
                    )
                }

                Spacer(Modifier.height(20.dp))

                // Gauge card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SURFACE, RoundedCornerShape(24.dp))
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("$score%", color = CYAN, fontWeight = FontWeight.Black, fontSize = 48.sp)
                    Text("ishlash tezligi", color = MUTED, fontSize = 12.sp)
                    Spacer(Modifier.height(16.dp))
                    Text(statusLog, color = MUTED, fontSize = 11.sp, modifier = Modifier.padding(bottom = 10.dp))

                    Button(
                        onClick = {
                            if (!ShizukuHelper.isGranted.value) {
                                ShizukuHelper.requestPermission()
                                return@Button
                            }
                            boosting = true
                            scope.launch {
                                val svc = ShizukuHelper.service
                                var stopped = 0
                                for (app in runningApps) {
                                    svc?.forceStopPackage(app.pkg)
                                    stopped++
                                }
                                svc?.trimSystemCaches()
                                refreshRam()
                                score = minOf(98, score + 20 + stopped)
                                statusLog = "$stopped ta dastur to'xtatildi, kesh qisqartirildi"
                                boosting = false
                            }
                        },
                        enabled = !boosting,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CYAN),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Text(
                            if (boosting) "TOZALANMOQDA..."
                            else if (!ShizukuHelper.isGranted.value) "SHIZUKUGA ULANISH"
                            else "TEZLASHTIRISH",
                            color = BG, fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))

                // Stats row
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("${freeRam / (1024 * 1024)} MB", "bo'sh RAM", Modifier.weight(1f))
                    StatCard("${runningApps.size} ta", "fon dastur", Modifier.weight(1f))
                    StatCard(if (ShizukuHelper.isGranted.value) "to'liq" else "cheklangan", "rejim", Modifier.weight(1f))
                }

                Spacer(Modifier.height(24.dp))
                Text("Fonda ishlayotgan dasturlar", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))

                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(runningApps) { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(SURFACE, RoundedCornerShape(14.dp))
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(app.label, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                scope.launch {
                                    if (ShizukuHelper.isGranted.value) {
                                        ShizukuHelper.service?.forceStopPackage(app.pkg)
                                        runningApps = runningApps.filter { it.pkg != app.pkg }
                                        refreshRam()
                                    }
                                }
                            }) {
                                Text("To'xtatish", color = CYAN, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(SURFACE, RoundedCornerShape(16.dp))
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(label, color = MUTED, fontSize = 10.sp)
    }
}
