package com.tezkor.booster

import android.content.Intent
import android.content.pm.PackageManager
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun StorageScreen() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(StorageUtil.isUsageAccessGranted(ctx)) }
    var loading by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<AppStorage>>(emptyList()) }
    val scope = rememberCoroutineScope()

    fun load() {
        loading = true
        scope.launch {
            results = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                StorageUtil.analyze(ctx)
            }
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Xotira tahlili", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(6.dp))
        Text("Qaysi dasturlar eng ko'p joy egallayotganini ko'rsatadi.", color = MUTED, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))

        if (!granted) {
            Column(Modifier.fillMaxWidth().background(SURFACE, RoundedCornerShape(14.dp)).padding(14.dp)) {
                Text("Ishlashi uchun \"Foydalanish ma'lumotlariga kirish\" ruxsatini bering.", color = AMBER, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }, colors = ButtonDefaults.buttonColors(containerColor = CYAN)) {
                    Text("RUXSAT BERISH", color = BG, fontSize = 12.sp)
                }
                Spacer(Modifier.height(6.dp))
                TextButton(onClick = { granted = StorageUtil.isUsageAccessGranted(ctx); if (granted) load() }) {
                    Text("Tekshirish", color = MUTED, fontSize = 11.sp)
                }
            }
        } else {
            Button(
                onClick = { load() },
                enabled = !loading,
                colors = ButtonDefaults.buttonColors(containerColor = VIOLET),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (loading) "HISOBLANMOQDA..." else "TAHLIL QILISH", color = Color.White, fontSize = 12.sp)
            }
            Spacer(Modifier.height(14.dp))
            LazyColumn {
                items(results) { app ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            .background(SURFACE, RoundedCornerShape(14.dp)).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(app.label, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Text("${app.bytes / (1024 * 1024)} MB", color = CYAN, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
fun GameTurboScreen(pm: PackageManager) {
    val ctx = LocalContext.current
    val apps = remember { AppListUtil.installedApps(pm) }
    var games by remember { mutableStateOf(Prefs.getGameApps(ctx)) }
    var turboOn by remember { mutableStateOf(Prefs.isGameTurboOn(ctx)) }
    val overlayGranted = remember { mutableStateOf(android.provider.Settings.canDrawOverlays(ctx)) }
    val usageGranted = remember { mutableStateOf(StorageUtil.isUsageAccessGranted(ctx)) }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("O'yin Turbo", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(6.dp))
        Text("Tanlangan o'yin ochilganda ekranga kichik panel (RAM, tarmoq, FPS imkoniyati, tez tozalash) chiqadi.", color = MUTED, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))

        if (!overlayGranted.value || !usageGranted.value) {
            Column(Modifier.fillMaxWidth().background(SURFACE, RoundedCornerShape(14.dp)).padding(14.dp)) {
                Text("Kerakli ruxsatlar:", color = AMBER, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                if (!overlayGranted.value) {
                    Button(onClick = {
                        ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            android.net.Uri.parse("package:${ctx.packageName}")))
                    }, colors = ButtonDefaults.buttonColors(containerColor = CYAN), modifier = Modifier.fillMaxWidth()) {
                        Text("1) Boshqa ilovalar ustida chizish", color = BG, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                }
                if (!usageGranted.value) {
                    Button(onClick = {
                        ctx.startActivity(Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    }, colors = ButtonDefaults.buttonColors(containerColor = CYAN), modifier = Modifier.fillMaxWidth()) {
                        Text("2) Foydalanish ma'lumotlariga kirish", color = BG, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                }
                TextButton(onClick = {
                    overlayGranted.value = android.provider.Settings.canDrawOverlays(ctx)
                    usageGranted.value = StorageUtil.isUsageAccessGranted(ctx)
                }) { Text("Tekshirish", color = MUTED, fontSize = 11.sp) }
            }
            Spacer(Modifier.height(14.dp))
        }

        SettingCard(
            title = "O'yin Turbo",
            subtitle = if (turboOn) "Faol — tanlangan o'yinlarda panel chiqadi" else "O'chiq"
        ) {
            Switch(
                checked = turboOn,
                enabled = overlayGranted.value && usageGranted.value,
                onCheckedChange = {
                    turboOn = it
                    Prefs.setGameTurboOn(ctx, it)
                    val intent = Intent(ctx, GameTurboService::class.java)
                    if (it) ctx.startForegroundService(intent) else ctx.stopService(intent)
                },
                colors = SwitchDefaults.colors(checkedTrackColor = CYAN)
            )
        }

        Spacer(Modifier.height(16.dp))
        Text("O'yinlarni tanlang", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(apps) { app ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        .background(SURFACE, RoundedCornerShape(14.dp)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(app.label, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Switch(
                        checked = app.pkg in games,
                        onCheckedChange = { checked ->
                            games = if (checked) games + app.pkg else games - app.pkg
                            Prefs.setGameApps(ctx, games)
                        },
                        colors = SwitchDefaults.colors(checkedTrackColor = CYAN)
                    )
                }
            }
        }
    }
}

@Composable
fun NotifBlockScreen(pm: PackageManager) {
    val ctx = LocalContext.current
    val apps = remember { AppListUtil.installedApps(pm) }
    var blocked by remember { mutableStateOf(Prefs.getBlockedNotifApps(ctx)) }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Bildirishnomalarni bloklash", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(6.dp))
        Text("Tanlangan dasturlarning bildirishnomalari avtomatik o'chiriladi.", color = MUTED, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            ctx.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }, colors = ButtonDefaults.buttonColors(containerColor = CYAN)) {
            Text("RUXSAT BERISH", color = BG, fontSize = 12.sp)
        }
        Spacer(Modifier.height(16.dp))
        LazyColumn {
            items(apps) { app ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        .background(SURFACE, RoundedCornerShape(14.dp)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(app.label, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Switch(
                        checked = app.pkg in blocked,
                        onCheckedChange = { checked ->
                            blocked = if (checked) blocked + app.pkg else blocked - app.pkg
                            Prefs.setBlockedNotifApps(ctx, blocked)
                        },
                        colors = SwitchDefaults.colors(checkedTrackColor = CYAN)
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var batterySaver by remember { mutableStateOf(Prefs.isBatterySaverOn(ctx)) }
    var schedule by remember { mutableStateOf(Prefs.isScheduleOn(ctx)) }
    var benchScore by remember { mutableStateOf<Int?>(null) }
    var benchRunning by remember { mutableStateOf(false) }
    var cooling by remember { mutableStateOf(false) }
    var coolDone by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(androidx.compose.foundation.rememberScrollState())
            .padding(20.dp)
    ) {
        Text("Sozlamalar", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(16.dp))

        // Batareya tejash
        SettingCard(title = "Batareya tejash rejimi", subtitle = "Tizimning batareya tejash rejimini ochadi") {
            Switch(checked = batterySaver, onCheckedChange = {
                batterySaver = it
                Prefs.setBatterySaverOn(ctx, it)
                ctx.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, colors = SwitchDefaults.colors(checkedTrackColor = CYAN))
        }

        Spacer(Modifier.height(10.dp))

        // Avtomatik tozalash
        SettingCard(title = "Avtomatik tozalash", subtitle = "Har kuni fonda tizim keshini tozalaydi (Shizuku kerak)") {
            Switch(checked = schedule, onCheckedChange = {
                schedule = it
                Prefs.setScheduleOn(ctx, it)
                if (it) CleanupWorker.schedule(ctx) else CleanupWorker.cancel(ctx)
            }, colors = SwitchDefaults.colors(checkedTrackColor = CYAN))
        }

        Spacer(Modifier.height(10.dp))

        // Tezlik testi
        Column(Modifier.fillMaxWidth().background(SURFACE, RoundedCornerShape(16.dp)).padding(16.dp)) {
            Text("Tezlik testi (benchmark)", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("Protsessor tezligini real hisoblash orqali o'lchaydi", color = MUTED, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            if (benchScore != null) {
                Text("Natija: ${benchScore}/100 ball", color = CYAN, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
            }
            Button(
                onClick = {
                    benchRunning = true
                    scope.launch {
                        val (score, _) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                            BenchmarkUtil.run()
                        }
                        benchScore = score
                        benchRunning = false
                    }
                },
                enabled = !benchRunning,
                colors = ButtonDefaults.buttonColors(containerColor = VIOLET)
            ) {
                Text(if (benchRunning) "O'LCHANMOQDA..." else "TESTNI BOSHLASH", color = Color.White, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(10.dp))

        // Issiqlikni pasaytirish
        Column(Modifier.fillMaxWidth().background(SURFACE, RoundedCornerShape(16.dp)).padding(16.dp)) {
            Text("Issiqlikni pasaytirish", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("Og'ir fon jarayonlarini to'xtatib, qurilmani sovutishga yordam beradi", color = MUTED, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            if (coolDone) {
                Text("✓ Qurilma sovutildi", color = GREEN, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
            }
            Button(
                onClick = {
                    cooling = true
                    scope.launch {
                        val svc = ShizukuHelper.service
                        AppListUtil.installedApps(ctx.packageManager).forEach { svc?.forceStopPackage(it.pkg) }
                        kotlinx.coroutines.delay(1500)
                        cooling = false
                        coolDone = true
                    }
                },
                enabled = !cooling,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
            ) {
                Text(if (cooling) "SOVUTILMOQDA..." else "HOZIR SOVUTISH", color = Color.White, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SettingCard(title: String, subtitle: String, control: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(SURFACE, RoundedCornerShape(16.dp)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = MUTED, fontSize = 11.sp)
        }
        control()
    }
}


