package com.tezkor.booster

import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Process
import android.os.storage.StorageManager

data class AppStorage(val label: String, val pkg: String, val bytes: Long)

object StorageUtil {

    /** Har bir dasturning egallagan hajmini (APK + ma'lumot + kesh) hisoblaydi. */
    fun analyze(ctx: Context): List<AppStorage> {
        val pm = ctx.packageManager
        val statsManager = ctx.getSystemService(Context.STORAGE_STATS_SERVICE) as? StorageStatsManager
            ?: return emptyList()
        val result = mutableListOf<AppStorage>()
        val apps = AppListUtil.installedApps(pm)

        for (app in apps) {
            try {
                val uid = pm.getApplicationInfo(app.pkg, 0).uid
                val stats = statsManager.queryStatsForUid(StorageManager.UUID_DEFAULT, uid)
                val total = stats.appBytes + stats.dataBytes + stats.cacheBytes
                result.add(AppStorage(app.label, app.pkg, total))
            } catch (e: Exception) {
                // Ruxsat yo'q yoki o'qib bo'lmadi — shu dasturni o'tkazib yuboramiz
            }
        }
        return result.sortedByDescending { it.bytes }
    }

    fun isUsageAccessGranted(ctx: Context): Boolean {
        return try {
            val uid = Process.myUid()
            val mode = (ctx.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager)
                .checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, uid, ctx.packageName)
            mode == android.app.AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) { false }
    }
}
