package com.tezkor.booster

import android.content.Context

/** Ilova sozlamalarini saqlash (qulflangan dasturlar, PIN, bloklangan bildirishnomalar va h.k.) */
object Prefs {
    private const val NAME = "tezkor_prefs"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun getLockedApps(ctx: Context): Set<String> =
        sp(ctx).getStringSet("locked_apps", emptySet()) ?: emptySet()

    fun setLockedApps(ctx: Context, set: Set<String>) =
        sp(ctx).edit().putStringSet("locked_apps", set).apply()

    fun getBlockedNotifApps(ctx: Context): Set<String> =
        sp(ctx).getStringSet("blocked_notif_apps", emptySet()) ?: emptySet()

    fun setBlockedNotifApps(ctx: Context, set: Set<String>) =
        sp(ctx).edit().putStringSet("blocked_notif_apps", set).apply()

    fun getPin(ctx: Context): String? = sp(ctx).getString("pin", null)
    fun setPin(ctx: Context, pin: String) = sp(ctx).edit().putString("pin", pin).apply()

    fun isBatterySaverOn(ctx: Context): Boolean = sp(ctx).getBoolean("battery_saver", false)
    fun setBatterySaverOn(ctx: Context, on: Boolean) = sp(ctx).edit().putBoolean("battery_saver", on).apply()

    fun isScheduleOn(ctx: Context): Boolean = sp(ctx).getBoolean("schedule_on", false)
    fun setScheduleOn(ctx: Context, on: Boolean) = sp(ctx).edit().putBoolean("schedule_on", on).apply()

    fun getGameApps(ctx: Context): Set<String> =
        sp(ctx).getStringSet("game_apps", emptySet()) ?: emptySet()
    fun setGameApps(ctx: Context, set: Set<String>) =
        sp(ctx).edit().putStringSet("game_apps", set).apply()

    fun isGameTurboOn(ctx: Context): Boolean = sp(ctx).getBoolean("game_turbo_on", false)
    fun setGameTurboOn(ctx: Context, on: Boolean) = sp(ctx).edit().putBoolean("game_turbo_on", on).apply()

    fun isAppUnlockedThisSession(ctx: Context, pkg: String): Boolean =
        sp(ctx).getLong("unlocked_$pkg", 0) > System.currentTimeMillis() - 60_000

    fun markUnlocked(ctx: Context, pkg: String) =
        sp(ctx).edit().putLong("unlocked_$pkg", System.currentTimeMillis()).apply()
}
