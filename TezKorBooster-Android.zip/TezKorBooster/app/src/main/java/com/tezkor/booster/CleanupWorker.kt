package com.tezkor.booster

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.ExistingPeriodicWorkPolicy
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.delay

/** Har kuni avtomatik ravishda tizim keshini tozalaydigan fon vazifasi (Shizuku orqali). */
class CleanupWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        return try {
            ShizukuHelper.checkAvailability()
            delay(1500) // ulanish uchun qisqa kutish
            ShizukuHelper.service?.trimSystemCaches()
            Result.success()
        } catch (e: Throwable) {
            Result.retry()
        }
    }

    companion object {
        private const val TAG = "tezkor_daily_cleanup"

        fun schedule(ctx: Context) {
            val request = PeriodicWorkRequestBuilder<CleanupWorker>(1, TimeUnit.DAYS).build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork(TAG, ExistingPeriodicWorkPolicy.UPDATE, request)
        }

        fun cancel(ctx: Context) {
            WorkManager.getInstance(ctx).cancelUniqueWork(TAG)
        }
    }
}
