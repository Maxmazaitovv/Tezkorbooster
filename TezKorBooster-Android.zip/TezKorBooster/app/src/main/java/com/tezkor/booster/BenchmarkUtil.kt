package com.tezkor.booster

/** Haqiqiy protsessor yukini (tub sonlarni sanash) ishga tushirib, tezlikni o'lchaydi. */
object BenchmarkUtil {

    // Qaytaradi: (ball 0-100, millisekundda ketgan vaqt)
    fun run(): Pair<Int, Long> {
        val start = System.currentTimeMillis()
        var count = 0
        var n = 2
        // 1.5 soniyaga yaqin vaqt davomida nechta tub son topilishini sanaydi
        while (System.currentTimeMillis() - start < 1200) {
            if (isPrime(n)) count++
            n++
        }
        val elapsed = System.currentTimeMillis() - start
        // Taxminiy normalash: ~45000+ tub son — yuqori ball
        val score = (count / 450).coerceIn(10, 100)
        return Pair(score, elapsed)
    }

    private fun isPrime(num: Int): Boolean {
        if (num < 2) return false
        var i = 2
        while (i * i <= num) {
            if (num % i == 0) return false
            i++
        }
        return true
    }
}
