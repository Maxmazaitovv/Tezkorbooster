package com.tezkor.booster

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.IBinder
import androidx.compose.runtime.mutableStateOf
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.ShizukuRemoteProcess

/**
 * Shizuku bilan bog'lanish holatini boshqaradi:
 * 1) Shizuku ilovasi o'rnatilganmi va ishga tushganmi
 * 2) Ruxsat berilganmi
 * 3) Ruxsat berilsa — UserService orqali tizim amallarini bajaradi
 */
object ShizukuHelper {

    const val REQUEST_CODE = 1001

    val isAvailable = mutableStateOf(false)
    val isGranted = mutableStateOf(false)
    var service: IUserService? = null
        private set

    private val userServiceArgs = Shizuku.UserServiceArgs(
        ComponentName("com.tezkor.booster", UserService::class.java.name)
    )
        .daemon(false)
        .processNameSuffix("tezkor_service")
        .debuggable(false)
        .version(1)

    private val connection = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = IUserService.Stub.asInterface(binder)
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
        }
    }

    fun checkAvailability() {
        isAvailable.value = try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
        if (isAvailable.value) {
            isGranted.value = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            if (isGranted.value) bindService()
        }
    }

    fun requestPermission() {
        try {
            if (Shizuku.isPreV11()) return // juda eski Shizuku versiyasi qo'llab-quvvatlanmaydi
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                isGranted.value = true
                bindService()
                return
            }
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            // Shizuku hali tayyor emas yoki ruxsat so'rashda xato — ilova yiqilmasligi uchun ushlab qolamiz
        }
    }

    fun bindService() {
        try {
            Shizuku.bindUserService(userServiceArgs, connection)
        } catch (e: Throwable) {
            // Ulanishda xato bo'lsa ham ilova ishlashda davom etadi
        }
    }
}
