package com.tezkor.booster

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

object AppListUtil {
    fun installedApps(pm: PackageManager): List<AppInfo> =
        pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter {
                (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
                it.packageName != "com.tezkor.booster" &&
                pm.getLaunchIntentForPackage(it.packageName) != null
            }
            .map { AppInfo(pm.getApplicationLabel(it).toString(), it.packageName, null) }
}
